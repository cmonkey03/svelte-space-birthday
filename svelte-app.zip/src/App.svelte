<script>
	let name = 'world';
</script>

<h1>Hello {name}!</h1>